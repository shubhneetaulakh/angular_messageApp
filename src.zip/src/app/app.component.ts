import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  IsVisibleSuccess = false;
  IsVisibleWarning = false;
successFun() {
  this.IsVisibleWarning = false;
  this.IsVisibleSuccess = true;
  //alert("this.IsVisibleSuccess " + this.IsVisibleSuccess);
}
warningFun()
{
  this.IsVisibleSuccess = false;
  this.IsVisibleWarning = true;
   //alert("this.IsVisibleWarning " + this.IsVisibleWarning);
}
}
